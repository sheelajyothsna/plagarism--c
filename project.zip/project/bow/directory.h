int directory(char direction[100],char fileslist[100][100])
{
	// char files[100][100] = {'\0'};
	int count = 0;
	DIR *p;
	struct dirent *pp; 
	chdir(direction);     
	p = opendir (direction);
	if (p != NULL)
	{
		while ((pp = readdir (p))!=NULL) 
		{
			int length = strlen(pp->d_name);
			if (strncmp(pp->d_name + length - 4, ".txt", 4) == 0) 
			{
				//for(int k=0;k<strlen(pp->d_name);k++)
					//fileslist[count][k] = pp->d_name[k]; 
				//puts (pp->d_name);
				strcpy(fileslist[count],pp->d_name);
				count++;
	      		}
	    	}

	(void) closedir (p);
	}

	// for(int i = 0;i<count;i++)
	// {
	// 	printf("\n%s",list[i] );
	// }

	return count;
}