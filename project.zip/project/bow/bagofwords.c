#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include <ctype.h>
#include "directory.h"

struct dict
{
	char key[100];				//defining global structure 
	int value;
};								


int storefilecontents(char *,struct dict freq[]);					//prototypes for functions
int frequency(char a[500][500], int len, struct dict freq[500]);
int numerator(struct dict freq1[500],int l,struct dict freq2[500], int l2);
int euclidian(struct dict freq[],int l);
float dotproduct(int p, int d1,int d2);
int directory(char direction[100], char fileslist[100][100]);
void multiplefiles(char fileslist[100][100],int i);


int main(int argc, char *argv[])			//main function for reading directory and taking files into files list and printing them and sending for multiple file calculation.
{

	char fileslist[100][100]={'\0'};
	int nofiles=directory(argv[1],fileslist); 		//command line arguments	
	printf(": check : ");
	for(int i=0;i<nofiles;i++)
	{
		printf("%11.8s ",fileslist[i] );
	}
	multiplefiles(fileslist,nofiles);

	return 0;
 }


void multiplefiles(char fileslist[100][100],int count)				//accessing multiple files for percentages
{
	
	char fn1[50];
	char fn2[50];
	int l1,l2;
	int b,p;
	float percent,d1,d2;
	struct dict freq1[1000]={'\0'};
	struct dict freq2[1000]={'\0'};
	
	for(int g=0;g<count;g++)
	{
		printf("\n");
		printf("%8s",fileslist[g]);					//matrix form printing

		for(int h = 0;h<count;h++)					//sending multiple files for different functions
		{
			struct dict freq1[1000]={'\0'};				//every time cleaning the files to remove garbage values
			struct dict freq2[1000]={'\0'};
			
			
			
			for(b=0;b<strlen(fileslist[g]);b++)	
				fn1[b] = fileslist[g][b];
			fn1[b] = '\0';
			for(b=0;b<strlen(fileslist[g]);b++)
				fn2[b] = fileslist[h][b];
			fn2[b] = '\0';

			if((strcmp(fileslist[g],fileslist[h]))==0)
			{
				printf("%12s","NULL");
			}
			else
			{
			l1=storefilecontents(fn1,freq1);		//sending files to store in structure
			l2=storefilecontents(fn2,freq2);
			p=numerator(freq1,l1,freq2,l2);			//dot product numerator formula
			d1= euclidian(freq1,l1);
			d2= euclidian(freq2,l2);				//euclidian product
			percent=dotproduct(p,d1,d2);
			printf(" %11.2f",percent*100);			//printing percentages
			}

		}
		
	}
}


int storefilecontents(char fn[50],struct dict freq[])			//storing the file contents into structural array and frequency of each word
{
	FILE *fp;												//file pointer
	fp=fopen(fn,"r");										//opening file and reading it
	char f[500][500]={'0'},c;								//to avoid garbage values
	int i=0,j=0;
	while(1)
	{
		c=fgetc(fp);										//reading character by character and storing them in 2_D array
		int ascii=(int)(c);

		if(c==EOF)
		
			break;										//breaking infinite while loop at the end of file
		
		else if(c==' '|| c=='\n')
		{												//reading spaces and next lines
			f[i][j]='\0';
			i++;
			j=0;
		}
		if((ascii>=65 && ascii <=90) || (ascii>=97 && ascii<=122))
		{
		f[i][j]=tolower(c);									//coverting total string into lower case
		j++;
		}

	}
	int len=i+1;
	fclose(fp);
	return frequency(f,len,freq);						//returning freq values to frequency function
}


int frequency(char a[500][500], int len, struct dict freq[500])
{
	int m,n,c=0,x,i;
	for(m=0;m<len;m++)
	{
		x=0;
		
		for(n = 0 ; n <m ; n++)
		{
			
			if(strcmp(freq[n].key,a[m])==0)				//if value is present increase freq value
			{
				freq[n].value++;
				x=1;
			}
		}
		if(x == 0)
		{
			for(i=0;a[m][i] != '\0';i++)
			{
			freq[c].key[i]=a[m][i];				//add the word and freq value by 1
			freq[c].value = 1;
			}
		
		freq[c].key[i]='\0';
		c++;
		
		}

	}

	return c;

}


int numerator(struct dict freq1[],int l1,struct dict freq2[], int l2)   //dot product numerator
{
	int dp=0;
	for(int i=0;i<l1;i++)
	{
		for(int j=0;j<l2;j++)
		{
			if(strcmp(freq1[i].key,freq2[j].key)==0)
			{
				dp+=freq1[i].value*freq2[j].value;				//formula for numerator
			}
		}
		
	}
	
	return dp;								//return the dp value to multiplefiles function
}


int  euclidian(struct dict freq[],int l)
{
	int y=0;
	
	for(int i=0;i<l;i++)
	{
		y+=(freq[i].value*freq[i].value);   //euclidian norm function and formula
	}
	
	return y;
}


float dotproduct(int p, int d1, int d2)
{
	float percentage;
	if(d1!=0 && d2!=0){
	
	percentage=(p/(sqrt(d1)*sqrt(d2)));    //combining both numerator and euclidian 
	
	return percentage;						//return percentage
}
else
{
	printf("\n divide by zero" );
	return 00.00;
}
}


