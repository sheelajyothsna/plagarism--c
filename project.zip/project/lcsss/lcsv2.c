#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include <string.h>
#include <ctype.h>
#include "directory.h" //user defined header file

char f1[100][100]={'\0'}; 		//global declaration of 2_D array to store content of files
char f2[100][100]={'\0'};
char ch[100]={'\0'};				//for 2_D array content in 1_D array without spaces
char b[100]={'\0'};
char a[100]={'\0'};				//for storing lcs.
float lcs;
int w1,w2;


int storefilecontent(char fn[50],char f[100][100]);
float stringmatch(char f1[100][100], int len1, char f2[100][100], int len2);
float percentage();															//prototypes for functions
int directory(char direction[100],char fileslist[100][100]);
void multiplefiles(char fileslist[100][100],int count);



int main(int argc, char *argv[])		//main function for reading directory and taking files into files list and printing them and sending for multiple file calculation.
{
	
	char fileslist[100][100]={'\0'};
	int nofiles= directory(argv[1],fileslist);		//command line arguments
	printf(": check : ");
	
	for(int i=0;i<nofiles;i++)
	{
		printf("%11.8s ",fileslist[i] );
	}

	multiplefiles(fileslist,nofiles);
	
}


void multiplefiles(char fileslist[100][100],int count) 					//accessing multiple files for percentages
{
	
	for(int g=0;g<count;g++)
	{
		
		printf("\n");
		printf("%8s",fileslist[g]);			//matrix form printing

		for(int h = 0;h<count;h++)			//sending multiple files for different functions
		{
			char fn1[50];
			char fn2[50];
			int l1,l2;
			int b;
			float percent;

			memset(f1,'\0',sizeof(f1));		//every time cleaning the files to remove garbage values
			memset(f2,'\0',sizeof(f2));
			
			
			
			for(b=0;b<strlen(fileslist[g]);b++)
			{	
				fn1[b] = fileslist[g][b];
			}
			fn1[b] = '\0';
			for(b=0;b<strlen(fileslist[g]);b++)
			{
				fn2[b] = fileslist[h][b];
			}
			fn2[b] = '\0';
			
			if((strcmp(fileslist[g],fileslist[h]))==0)
			{
				printf("%12s","NULL");
			}
			else
			{
			int l1=storefilecontent(fn1,f1);			//sending files and file store for function.
			int l2=storefilecontent(fn2,f2);
			lcs=stringmatch(f1,l1,f2,l2);		//sending files to comparison method for finding lcs
			
			float percent =percentage();		// calling percentage function
			printf(" %11.2f",percent*100);		// print percentages
			}

		}
		
	}
}


int storefilecontent(char fn[50], char f[100][100])		//storeing file content into 2-D array.
{
	FILE *fp;											// file pointer
	fp=fopen(fn,"r");									//opening and reading file.
	char c;
	int i=0,j=0,letters=0;
	while(1)
	{
		c=fgetc(fp);										//reading character by character.
		

		int ascii=(int)(c);									//ascii values for each character

		if(c==EOF)
		
			break;											// to break infinite while loop
		
		else if(c==' '|| c=='\n')							//to consider spaces and new lines
		{
			f[i][j]='\0';
			i++;
			j=0;
			
		}
		if((ascii>=65 && ascii <=90) || (ascii>=97 && ascii<=122))			//to take only alphabets 
		{
		f[i][j]=tolower(c);							//converting all uppercase to lower.
		j++;
		letters++;
		}

	}
	int len=i+1;
	
	fclose(fp);											//closing file.
	
	return len;
}


float stringmatch(char f1[100][100], int l1, char f2[100][100], int l2)		//to find largest common substring passing files as paarameters
{
	int len,i,lcs=0;
	w1=0,w2=0;
	memset(a,'\0',sizeof(a));					//cleaning the arrays in order to avoid garbage values
	memset(b,'\0',sizeof(b));
	memset(ch,'\0',sizeof(ch));
	for(i=0;i<l1;i++)
	{
		strcat(b,f1[i]);			//storing the 2_d array to 1_D array
	}
	for(i=0;i<l2;i++)
	{
		strcat(ch,f2[i]);
	}
	
    w1=strlen(b);
	w2=strlen(ch);
    
    lcs=0;
    int j,t,k;
    for(i=0;i<w1;i++)
    {
        for(j=0;j<w2;j++)			//comparing character by character

        {
            memset(a,'\0',sizeof(a));
            k=0;
            t=i;
            while(i<w1 && j<w2 && b[i]==ch[j])
            {
              a[k]= b[i] ;
                i++;
                j++;
                k++;
            }
            len=k;
            if(len != 0){
                if(a[0]==' ' && a[k-1]==' ')			// removing spaces and adding the lcs content
                {
                    len=len-2;
                }
                else if(a[0]==' ' || a[k-1]==' ')
                {
                    len--;
                }
                if(lcs<len)
                {
                    lcs=len;
                }
            }
            i=t;
        }
    }
    
    return lcs;
}


float percentage()				//percentage calculation
{
	int i;
	//float x=0,y=0;
	
	float percent;
	if(w1!=0 && w2!=0)
	{
		percent=((lcs*2)/(w1+w2));		// formula calculation.
		return percent;						//return the percent
	}
	else
	{
		printf("\n divide by zero" );
		return 00.00;
	}
						
}

