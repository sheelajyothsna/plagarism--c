#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
#include <dirent.h>
#include <ctype.h>
#include "directory.h"			//user defined header file



int hash1[100]={0};					//hash values global declaration
int hash2[100]={0};
char f1[100][100]={'\0'};			// two dimensional arrays for storing the content of files
char f2[100][100]={'\0'};
int arraylen1,arraylen2;			//global declaration of lengths for hash valu array
char rd[100][100]={'\0'};															//rd indicates the two dimensional array for storing the k-gram division strings.

int storefilecontent(char fn[50],char f[100][100]);
int directory(char direction[100],char fileslist[100][100]);				//prototypes for functions
int hashvalues(char f[100][100],int len,int hash[100]);
float commonhashvalues(int hash1[100], int arraylen1, int hash2[100], int arraylen2);
void multiplefiles(char fileslist[100][100],int i);

int main(int argc, char *argv[])							//main function for reading directory and taking files into files list and printing them and sending for multiple file calculation.
{
	
	char fileslist[100][100]={'\0'};
	int nofiles= directory(argv[1],fileslist);				//command line arguments
	printf(": check : ");
	for(int i=0;i<nofiles;i++)
	{
		printf("%11.8s ",fileslist[i] );
	}
	multiplefiles(fileslist,nofiles);

}


void multiplefiles(char fileslist[100][100],int count)				//accessing multiple files for percentages
{
	

	for(int g=0;g<count;g++)
	{
		
		printf("\n");
		printf("%8s",fileslist[g]);						//matrix form printing

		for(int h = 0;h<count;h++)						//sending multiple files for different functions
		{
			
			char fn1[50];
			char fn2[50];
			int l1,l2;
			int b,p;
			float percent;
			memset(f1,'\0',sizeof(f1));						//every time cleaning the files to remove garbage values
			memset(f2,'\0',sizeof(f2));
			
			for(b=0;b<strlen(fileslist[g]);b++)	
				fn1[b] = fileslist[g][b];
			fn1[b] = '\0';
			for(b=0;b<strlen(fileslist[g]);b++)
				fn2[b] = fileslist[h][b];
			fn2[b] = '\0';
			
			if((strcmp(fileslist[g],fileslist[h]))==0)
			{
				printf("%12s","NULL");
			}
			else
			{
			l1=storefilecontent(fn1,f1);					//sending files and file store for function.
			l2=storefilecontent(fn2,f2);
			arraylen1=hashvalues(f1,l1,hash1);				//sending file store and length of files to hashvalues function
			arraylen2=hashvalues(f2,l2,hash2);
			percent=commonhashvalues(hash1,arraylen1,hash2,arraylen2);		//sending bothfiles hash values and array lengths to commonhashvalues function.

			//printf("%f",percent );
			printf(" %11.2f",percent*100);				//printing output percentage
			}

		}
		
	}
}



int storefilecontent(char fn[50], char f[100][100])				//storeing file content into 2-D array.
{
	FILE *fp;													// file pointer
	fp=fopen(fn,"r");											//opening and reading file.
	char c;
	int i=0,j=0;
	while(1)
	{
		c=fgetc(fp);											//reading character by character.
		//printf("%c",c);
		int ascii=(int)(c);										//ascii values for each character

		if(c==EOF)												// to break infinite while loop
		
			break;
		
		else if(c==' '|| c=='\n')						//to consider spaces and new lines
		{
			f[i][j]='\0';
			i++;
			j=0;
		}
		if((ascii>=65 && ascii <=90) || (ascii>=97 && ascii<=122))				//to take only alphabets 
		{
		f[i][j]=tolower(c);							//converting all uppercase to lower.
		j++;
		}

	}
	int len=i+1;
	fclose(fp);												//closing file.
	return len;
}


int hashvalues(char f[100][100],int len,int hash[100])		//to find hash values of content of files
{
	char a[500]={'\0'};
	int i=0,j,p=0,q,r,x,y;
	char rd[100][100]={'\0'};
 	int arraylen=0;
	while(i<len)						//removing spaces and adding the content to 1_D array.
	{
		j=0;
		while(f[i][j]!='\0')
		{
			a[p]=f[i][j];
			p++;
			j++;
		}
		i++;		
	}
	int k=10;
	for(i=0;i<strlen(a)-(k-1);i++)		//according k-gram value dividing the 1_D array content and storing in 2_d array.
	{
		p=0;
		y=i;
		while(p<k){
			rd[i][p]=a[y];
			p++;
			y++;
		}
	}
	long long s;			//for storing larger hash values
	int g=0;
	for(q=0;q<i;q++)
	{
		s=0;
		g=0;
		for(r=0;r<strlen(rd[q]);r++)
		{
			s+=(rd[q][r]*pow(k,k-(r+1)));	//calculating the hash values.
			g=s%10007;						// modulo division by 10007.
			hash[q]=g;						//storing hash values in array

		}
	}
	arraylen=q;
	return arraylen;						//returning array length.
	
}


float commonhashvalues(int hash1[100], int arraylen1, int hash2[100], int arraylen2) //finding for common hash values.
{
	int i,j,e=0;
	float percent=0;
	if(arraylen1!=0 && arraylen2!=0)
	{
	for(i=0;i<arraylen1;i++)
	{
		for(j=0;j<arraylen2;j++)
		{
			if(hash1[i]==hash2[j])				//linear searching method.
			{
				e=e+1;
			}
		}
	}
	percent=(float)(2*e)/(arraylen1+arraylen2);   //formula for finding the percentage
	return percent;									//returning percent.
	}
	else
	{
		printf("\n divide by zero" );
		return 00.00;
	}								
}