package Bag;                        //package was created 
import java.io.*;                   //for files io package was imported
import java.lang.*;                //for exceptions 
import java.util.*;               //for scanning the inputs,arraylist,hashtable
import java.text.*;

public class Bow                   //creating class called bow              
{
	public static String Removespecial_spaces(File f)      //method for removing special characters and spaces
  {
    String s="";                        //empty string
    try                                 //try method if file is not empty
    {
      Scanner sc=new Scanner(f);        //scanner for file input
      String str,word;                  //taking two string variables
      while(sc.hasNextLine())           //for considering total file content
      {       
        str=sc.nextLine();              //checks for the nextline inorder find if the content is present or not and asssigning it to str
        str=str.toLowerCase();            //coverts to lower case
        for(int i=0;i<str.length();i++)
        {
          if((str.charAt(i)>96 && str.charAt(i)<123) || (str.charAt(i)>47 && str.charAt(i)<58) || str.charAt(i)=='_' || str.charAt(i)==' ')//removing special charcters
          {
            s+=""+str.charAt(i);   //adding to other string so that all special characters gets removed.
          
          }
        }
      }
      
    }
    catch(Exception e)                        //if any exception it will catch and throw msg
    {
      System.out.println(e);                //prints the kind of exception
    }
    return s;                                 //returns the string by removing special characters
  }
          
  

  public static HashMap<String, Integer> freq(String[] p)         //method for calculating frequency with one argument
  {
    HashMap<String,Integer> hm= new HashMap<String,Integer>();      //creating object for hash map
    //t count=0;
    for(int i=0;i<p.length;i++)
    {
      if(!hm.containsKey(p[i]))                                 //storing the keys and count of keys into the hashmap
      {
        hm.put(p[i],1);
      }
      else
      {
        hm.put(p[i],(Integer)hm.get(p[i])+1);           //if already key is present then add count by 1
      }
    }
    //System.out.println(hm);
    return hm;                                         // return hash map
  }
  public static int  numerator(HashMap <String, Integer>hm1,HashMap <String, Integer>hm2) //method for calculating numerator with two parameters
  {
    int s=0;
    for(String key:hm1.keySet())
    {
      if(hm2.containsKey(key))              //if two hashmaps have same key then multiplying their count values
      {
        s+=hm1.get(key)*hm2.get(key);
      }
    }
    //System.out.println(s);
    return s;                     // return sum value
  }
  public static double denominator(HashMap <String, Integer>hm) //method for calculating denominator with two parameters
  {
    int euclid=0;
    for(String key:hm.keySet())                         //for every key taking count values and adding them by squaring count
    {
      euclid+=(hm.get(key)*hm.get(key));
    }
    //System.out.println(Math.sqrt(euclid));
    return (Math.sqrt(euclid));                           //returning the sqrt term to the main method
  }
}