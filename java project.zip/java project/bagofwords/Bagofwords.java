import Bag.Bow;                                       //importing user defined package
import java.io.*;                                     //input and output package for files reading
import java.util.*;                                   //util package is for scanner,arraylist,hashmap
import java.lang.*;                                   //for exception.

public class Bagofwords                               //creating a class called bagofwords
{
  public static void main(String[] args)throws IOException        //main function in which all other methods are called and output is printed.
  {
  Reading_files rf=new Reading_files();                       //creating object for another class in order to use its properties and methods
  rf.Files_finding(args[0]);                                  //command line argument
  rf.Nooffiles();                                             //method present in the Reading_files class
  Bow pr=new Bow();                                           //imported package and creating object in order to use the methods
  int row,col;                                                //two variables for files implementation

  PrintStream o = new PrintStream(new File("output.txt"));     //inorder to print the output into logfile.
  PrintStream console = System.out;                            //taking the output stream to file stream
  System.setOut(o);                                             //it will set the output to the file created
  System.out.printf("--files--");
  for(int i=0;i<rf.nooffiles;i++)         
  {
    System.out.printf(" %11.8s",rf.file_names[i]);            //it is used for printing the files names inorder to differntiate
  }
  for(row=0;row<rf.nooffiles;row++)
  {
    System.out.println();
    System.out.printf("%8s",rf.file_names[row]);              //sending row and col files that is 1st and 2nd files and vice versa if 2 files are present
      for(col=0;col<rf.nooffiles;col++)
      {
        if(row==col)
        {
          System.out.printf("%12s","100");                     //if two files are same then there will be 100% matching
        }
        else
        {
          String str1,str2;                                   //taking two string variables      
          float f1=0;                     
          double e1,e2;
          int num;
          //String per="";
          str1="";                                        //assigning empty string to the string variables
          str2="";
          str1=pr.Removespecial_spaces(rf.files_path[row]);   //sending file path for the first file and below sending second file
          str2=pr.Removespecial_spaces(rf.files_path[col]);
          String[] p=str1.split(" ");                         //converting the string into string array based on spliting with spaces
          String[] q=str2.split(" ");
          //System.out.println(p.length);
          HashMap <String, Integer>hm1=pr.freq(p);            //taking hashmap for calculating frequency for two files
          HashMap <String, Integer>hm2=pr.freq(q);            
          num=pr.numerator(hm1,hm2);                          //sending two hash maps to numerator method.
          e1=pr.denominator(hm1);                             //calling denominator method
          e2=pr.denominator(hm2);
          percentage(num,e1,e2);                              //calling percentage method 
          //System.out.println(per);

           
        }
      }      
    }   
    Runtime rt  = Runtime.getRuntime();                       //in order provide log file when compiled we use this method
    Process q = rt.exec("notepad "+"C:\\Users\\Jyothsna\\Videos\\CSPP2-all\\java project\\bagofwords\\output.txt"); //location for log file creation
  
}

public static void percentage(int s,double e1,double e2) //static method for percentatge with 3 parameters.
{
    double percent;
    percent=(s/(e1*e2))*100;                            //formula for percentage calculation
    System.out.printf(" %11.2f",percent);               //percentage printing for all file comparision
}

}