import Long.Largest;          //importing user defined package
import java.io.*;             //input and output package for files reading
import java.lang.*;           //for exception.
import java.util.*;           //util package is for scanner,arraylist,hashmap
import java.text.*;

public class Lcss           //creating class called Lcss
{
  public static void main(String[] args)throws IOException  //main function in which all other methods are called and output is printed.
  {
  
  Reading_files2 rf=new Reading_files2();     //creating object for another class in order to use its properties and methods
  rf.Files_finding(args[0]);                    ////command line argument
  rf.Nooffiles();                               //method present in the Reading_files class
  Largest lg=new Largest();                      //imported package and creating object in order to use the methods
  int row,col;                                    //two variables for files implementation
  PrintStream o = new PrintStream(new File("output.txt"));  //inorder to print the output into logfile.
  PrintStream console = System.out;                           //taking the output stream to file stream
  System.setOut(o);                                         //it will set the output to the file created


  System.out.printf("--files--");
  for(int i=0;i<rf.nooffiles;i++)         
  {
    System.out.printf(" %11.8s",rf.file_names[i]);        //it is used for printing the files names inorder to differntiate
  }
  float e1,e2;
  for(row=0;row<rf.nooffiles;row++)
  {
    System.out.println();
    System.out.printf("%8s",rf.file_names[row]);  //sending row and col files that is 1st and 2nd files and vice versa if 2 files are present    
      for(col=0;col<rf.nooffiles;col++)
      {
        if(row==col)
        {
          System.out.printf("%12s","100");          //if two files are same then there will be 100% matching
        }
        else
        {
          String str1,str2;          //two string variables
          float f1=0;
          String per="";
          str1="";              //making string variables empty
          str2="";
          str1=lg.Removespecial_spaces(rf.files_path[row]);     ///sending file path for the first file and below sending second file 
          str2=lg.Removespecial_spaces(rf.files_path[col]);
          f1=lg.lcs(str1,str2);                               //sending string to lsc method inorder to find lcs
          percentage(f1,str1.length(),str2.length());          //for finding percentage
           
        }
      }      
    }
    Runtime rt  = Runtime.getRuntime();                                       //in order provide log file when compiled we use this method
    Process q = rt.exec("notepad "+"C:\\Users\\Jyothsna\\Videos\\CSPP2-all\\java project\\lcs\\output.txt");    //location for log file creation
  
  }

  public static void percentage(float largest,int st1len,int st2len)   //static method for calculatingpercentages
  {
    float percent;
    
    percent=((largest*2)/(st1len+st2len))*100;      //formula for finding the percentages
    
    System.out.printf(" %11.2f",percent);       //for printing the percentages
  }
}