package Long;               //package was created
import java.io.*;           //for files io package was imported
import java.lang.*;         //for exceptions
import java.util.*;       //for scanning the inputs,arraylist,hashtable
import java.text.*;
public class Largest
{           //creating class called largest
  public static String Removespecial_spaces(File f)   //method for removing special characters and spaces
    {
      String s="";              //empty string
      try                       //try method if file not found
      {
        Scanner sc=new Scanner(f);      //scanner for file input
        String str,word;                 //taking two string variables
        while(sc.hasNextLine())           //for considering total file content
        {       
          str=sc.nextLine();      //checks for the nextline inorder find if the content is present or not and asssigning it to str
          str=str.toLowerCase();      //coverts to lower case
          for(int i=0;i<str.length();i++)
          {
            if((str.charAt(i)>96 && str.charAt(i)<123) || (str.charAt(i)>47 && str.charAt(i)<58) || str.charAt(i)=='_')//removing special charcters
            {
              s+=""+str.charAt(i);          //adding to other string so that all special characters gets removed.
            
            }
          }
        }
        
      }
      catch(Exception e)                   //if any exception it will catch and throw msg
      {
        System.out.println(e);               //prints the kind of exception
      }
      return s;                              //returns the string by removing special characters
    }
  public static float lcs(String st1,String st2) //method for calculatinglargest common substring
  {
    int lcs=0,max;
    String maxlstr="";              //consider empty string
    for(int i=0;i<st1.length();i++)
    {
      for(int j=0;j<st2.length();j++)
      {
        String lstr="";
        int t=i;
        while (i<st1.length() && j<st2.length() && st1.charAt(i)==st2.charAt(j))      //comparing character by character
        {
          lstr+=st1.charAt(i);      //if they are same considering its length or else gbg to next character
          i++;
          j++;
        }
        if(lstr.length()!=0)      //if length not zero then calculating the length of max string
        {
          max=lstr.length();
          if(max>lcs)
          {
            lcs=max;
            maxlstr = lstr;         //putting the hihest string the empty string
          }
        }
        i=t;                        //for loop continuation
      }
    }
    //System.out.println(lcs);
   // System.out.println(maxlstr);
    return lcs;                 //returning lcs value to main function
  }
}