import Hashed.Finger;                         //importing user defined package
import java.io.*;                             //input and output package for files reading
import java.lang.*;                           //for exception.
import java.util.*;                             //util package is for scanner,arraylist,hashmap
import java.text.*;

public class Fingerprint                        ////creating a class called fingerprint
{
  public static void main(String[] args)throws IOException  //main function in which all other methods are called and output is printed.
  {
  Reading_files1 rf=new Reading_files1();               //creating object for another class in order to use its properties and methods
  rf.Files_finding(args[0]);                            ////command line argument
  rf.Nooffiles();                                       //method present in the Reading_files class
  Finger fg=new Finger();                                //imported package and creating object in order to use the methods
  int row,col;                                            //two variables for files implementation

  PrintStream o = new PrintStream(new File("output.txt"));    //inorder to print the output into logfile.
  PrintStream console = System.out;                           //taking the output stream to file stream
  System.setOut(o);                                           //it will set the output to the file created
  System.out.printf("--files--");
  for(int i=0;i<rf.nooffiles;i++)         
  {
    System.out.printf(" %11.8s",rf.file_names[i]);            //it is used for printing the files names inorder to differntiate
  }
  float e1,e2;
  for(row=0;row<rf.nooffiles;row++)
  {
    System.out.println();
    System.out.printf("%8s",rf.file_names[row]);     //sending row and col files that is 1st and 2nd files and vice versa if 2 files are present 
      for(col=0;col<rf.nooffiles;col++)
      {
        if(row==col)
        {
          System.out.printf("%12s","100");      //if two files are same then there will be 100% matching
        }
        else
        {
          String str1,str2;         //taking two string variables 
          float f1=0;
          String per="";
          str1="";                //assigning empty string to the string variables
          str2="";
          str1=fg.Removespecial_spaces(rf.files_path[row]);      //sending file path for the first file and below sending second file
          str2=fg.Removespecial_spaces(rf.files_path[col]);
          ArrayList<Integer> hash1=new ArrayList<Integer>();      //creating two objects for array list
          ArrayList<Integer> hash2=new ArrayList<Integer>();
          fg.hashvalues(str1,hash1);                            //calling method with two parameters
          fg.hashvalues(str2,hash2);
          freq(hash1,hash2);                                  //finding the frequency and calculating the percentages
        }
      }      
    }
    Runtime rt  = Runtime.getRuntime();                             //in order provide log file when compiled we use this method
    Process q = rt.exec("notepad "+"C:\\Users\\Jyothsna\\Videos\\CSPP2-all\\java project\\fingerprint\\output.txt"); //location for log file creation   
  }

  public static void freq(ArrayList<Integer> hash1,ArrayList<Integer> hash2) //static method for calculating percentages
  {
    //System.out.println(hash1);
    //System.out.println(hash2);
    int c=0;
    float percent;
    for(int i=0;i<hash1.size();i++)
    {
        //System.out.println(hash1.get(i));
        if(hash2.contains(hash1.get(i)))        //for finding the same hash values present in two files
        {
          //System.out.println("hi");
          c=c+1;
        }

      
    }
    //System.out.println(c);
    percent=((float)(2*c)/(hash1.size()+hash2.size()))*100;       //formula for calculating the percentage
    //System.out.println(percent*100);
    System.out.printf(" %11.2f",percent);               //printing the percentage
  }


}