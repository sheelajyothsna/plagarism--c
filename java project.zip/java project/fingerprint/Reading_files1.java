import Hashed.Finger;							//importing user defined package
import java.io.File;							//importing for files
import java.util.ArrayList;						// util package for all the required methods
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;


public class Reading_files1
{
	public static String file_names[]=new String[10];					//for files reading class was created
	public static int nooffiles;										// global declaration of of variables
	public static File[] files_path=new File[10];
	public static int row,col;
	//public static String path = null;
	
	public static void Files_finding(String userpath)			//static method for finding files
	{
		Scanner sc=new Scanner(System.in);
		String path= userpath;//sc.nextLine();					// taking path from user
		File folder = new File(path);							// creating object for file
		File[] listOfFiles = folder.listFiles();				// creating files array inorder to llist the no of files
		int k=0;		
		//System.out.println(Arrays.toString(listOfFiles));
		for (int i = 0; i < listOfFiles.length; i++)			
		{
		  File file = listOfFiles[i];							//sending files one by one to file variable
		  //System.out.println(file);
		  if (file.isFile() && file.getName().endsWith(".txt"))		//considering only text files
		  {
			  file_names[k]=file.getName();			  			//getting the name of the files
			  files_path[k]=file;								//taking the file path
			  //files_path[k]=file;								
			  //System.out.println(files_path[k]);
			  k++;
		  } 
		}
		
	}
	public static void Nooffiles()						//method for no of files
	{
		nooffiles=0;
		for(int i=0;files_path[i]!=null;i++)				//counting the values for noof files
		{
			nooffiles++;									//if file found incrementing the files by 1.
		}
	}
	
}
