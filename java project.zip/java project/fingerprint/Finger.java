package Hashed;               //package was created
import java.io.*;             //for files io package was imported
import java.lang.*;           //for exceptions
import java.util.*;           //for scanning the inputs,arraylist,hashtable
import java.text.*;
public class Finger{          //creating class called finger
public static String Removespecial_spaces(File f) //method for removing special characters and spaces
  {
    String s="";            //empty string
    try                     //try method if file is not empty
    {
      Scanner sc=new Scanner(f);      //scanner for file input
      String str,word;                //taking two string variables
      while(sc.hasNextLine())          //for considering total file content
      {       
        str=sc.nextLine();    //checks for the nextline inorder find if the content is present or not and asssigning it to str
        str=str.toLowerCase();        //coverts to lower case
        for(int i=0;i<str.length();i++)
        {
          if((str.charAt(i)>96 && str.charAt(i)<123) || (str.charAt(i)>47 && str.charAt(i)<58) || str.charAt(i)=='_')//removing special charcters
          {
            s+=""+str.charAt(i);            //adding to other string so that all special characters gets removed.
          
          }
        }
      }
      
    }
    catch(Exception e)                        //if any exception it will catch and throw msg
    {
      System.out.println(e);                  //prints the kind of exception
    }
    return s;                                     //returns the string by removing special characters
  }
  
  public static void hashvalues(String st, ArrayList<Integer> hash)//method for calulating hash valuses of words
  {
    String q=st.replace(" ","");          // replacing spaces by null character
    //System.out.println(q);
    String s;                       //string variable
    int k=10,i,y,p;
    int l=k;
    ArrayList<String> list=new ArrayList<String>();  //creating object for arraylist
    for(i=0;i<q.length()-(k-1);i++)
    {
      s="";
      p=0;
      y=i;
      while(p<k)          //for 10 letters in string
      {
        s+=q.charAt(y);
        p++;
        y++;
      }
      list.add(s);        //based on k value adding strings to the arraylist

    }
    
    //System.out.println(list);
    long j;
    long g=0;           //for large value storage
    for(i=0;i<list.size();i++)
    {
      j=0;
      g=0;
      String str="";
      for(int r=0;r<l;r++)
      {
        str=list.get(i);
        //System.out.println(str.charAt(r));
        j+=((int)str.charAt(r))*(Math.pow(k,k-(r+1))); //for every splited string calculate hash values
        
      }
      g=j%10007;          //calculate modulus of the hash value
      hash.add((int)g);     // adding the hash value to the arraylist

    } 
   // System.out.println(hash);

  }
}